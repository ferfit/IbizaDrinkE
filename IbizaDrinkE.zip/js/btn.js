
/* const btn = document.getElementById('btn-play');
const miVideo = document.getElementById('bg_video2');
const fotoVideo = document.getElementById('foto_video');


btn.addEventListener('click',()=>{
    fotoVideo.style.display="none";
    btn.style.display="none";
    miVideo.setAttribute("autoplay","true");
    miVideo.play();
})
 */